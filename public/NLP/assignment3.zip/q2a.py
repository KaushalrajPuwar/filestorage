#IMT2023063

import torch
import torch.nn.functional as F

class SelfAttention:
    def __init__(self, d_model):
        # Define learnable projection matrices for queries, keys, and values
        # Each of W_q, W_k, W_v has shape (d_model, d_k)
        self.W_q = ...
        self.W_k = ...
        self.W_v = ...

    def forward(self, x):
        # Input tensor x has shape (batch_size, seq_len, d_model)
        # Step 1: Map the input sequence into query, key, and value representations
        Q = x @ self.W_q
        K = x @ self.W_k
        V = x @ self.W_v

        # Step 2: Compute scaled dot-product attention scores between queries and keys
        d_k = Q.size(-1)  # dimensionality of the key/query vectors
        raw_scores = (Q @ K.transpose(-2, -1)) / (d_k ** 0.5)

        # Step 2.5: Introduce a causal mask to block access to subsequent positions
        # mask[i, j] = 1 when j > i (i.e. future tokens), otherwise 0
        seq_len = x.size(-2)
        mask = torch.triu(torch.ones(seq_len, seq_len), diagonal=1)
        mask = mask.to(raw_scores.device)

        raw_scores = raw_scores.masked_fill(mask == 1, float('-inf'))

        # Step 3: Apply softmax along the final dimension to obtain attention weights
        attention_weights = F.softmax(raw_scores, dim=-1)

        # Step 4: Form the output as a weighted combination of the value vectors
        contextualised_output = attention_weights @ V

        return contextualised_output
