#IMT2023063

import numpy as np

# 4. Softmax function
def softmax(x):
    e = np.exp(x - np.max(x, axis=-1, keepdims=True))
    return e / e.sum(axis=-1, keepdims=True)

def main():
    words = ["Dog", "Chasing", "Cat"]
    # 1. Define embeddings and weights
    X = np.array([[1, 0, 0], [1, 1, 0], [0, 1, 1]], dtype=float)
    W_Q = W_K = W_V = np.eye(3)

    # 2. Derive Q, K, V
    Q, K, V = X @ W_Q, X @ W_K, X @ W_V

    # 3. Calculate and scale scores. Using @ for dot product 
    scores = Q @ K.T
    scores_scaled = scores / np.sqrt(K.shape[1])
    
    # 5. Final computation
    weights = softmax(scores_scaled)
    out = weights @ V

    np.set_printoptions(precision=4, suppress=True)
    print("Input X:\n", X)
    print("\nScores:\n", scores)
    print("\nWeights (softmax rows):\n", weights)
    print("\nOutput (new representations):\n")
    
    for w, v in zip(words, out):
        print(f"{w}: {v}")

if __name__ == '__main__':
    main()
